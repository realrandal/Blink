# Search

Search related layouts.

Available layouts for the search are:

* Search/Button - Displays simple search form.
* Search/Form - Displays advanced search form.
* Search/Results - Displays search results.
